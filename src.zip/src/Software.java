public class Software extends Item {
    private String chave;

    public Software(String id, String nome, String chave) {
        super(id, nome);
        this.chave = chave;
    }

    @Override
    public String getDetalhes() {
        return "Software Licença: " + chave;
    }
}
