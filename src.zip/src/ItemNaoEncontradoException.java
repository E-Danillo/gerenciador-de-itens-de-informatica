public class ItemNaoEncontradoException extends Exception {
    public ItemNaoEncontradoException(String msg) {
        super(msg);
    }
}
