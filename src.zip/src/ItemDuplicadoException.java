public class ItemDuplicadoException extends Exception {
    public ItemDuplicadoException(String msg) {
        super(msg);
    }
}
