import java.util.List;

public interface Gerenciador {
    void adicionar(Item item) throws ItemDuplicadoException;
    void remover(String id) throws ItemNaoEncontradoException;
    Item buscar(String id) throws ItemNaoEncontradoException;
    List<Item> listar();
}
