import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        Estoque estoque = new Estoque();

        JFrame frame = new JFrame("Gerenciamento de Itens de Informática");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);

        JPanel panel = new JPanel(new BorderLayout());
        JTextArea area = new JTextArea();
        area.setEditable(false);
        panel.add(new JScrollPane(area), BorderLayout.CENTER);

        // Botões
        JButton addBtn = new JButton("Adicionar Item");
        JButton removeBtn = new JButton("Remover Item");
        JButton listarBtn = new JButton("Listar Itens");

        // Ação de adicionar
        addBtn.addActionListener(e -> {
            String tipo = JOptionPane.showInputDialog("Digite o tipo (hardware/software):");
            if (tipo == null) return;

            String id = JOptionPane.showInputDialog("ID do item:");
            if (id == null) return;

            String nome = JOptionPane.showInputDialog("Nome do item:");
            if (nome == null) return;

            String extra = JOptionPane.showInputDialog(
                    tipo.equalsIgnoreCase("hardware") ? "Serial number:" : "Chave de licença:");
            if (extra == null) return;

            try {
                Item item;
                if (tipo.equalsIgnoreCase("hardware")) {
                    item = new Hardware(id, nome, extra);
                } else {
                    item = new Software(id, nome, extra);
                }
                estoque.adicionar(item);
                JOptionPane.showMessageDialog(frame, "Item adicionado!");
            } catch (ItemDuplicadoException ex) {
                JOptionPane.showMessageDialog(frame, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Ação de remover
        removeBtn.addActionListener(e -> {
            String id = JOptionPane.showInputDialog("Digite o ID do item para remover:");
            if (id == null) return;
            try {
                estoque.remover(id);
                JOptionPane.showMessageDialog(frame, "Item removido!");
            } catch (ItemNaoEncontradoException ex) {
                JOptionPane.showMessageDialog(frame, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Ação de listar
        listarBtn.addActionListener(e -> {
            area.setText("");
            for (Item i : estoque.listar()) {
                area.append(i.toString() + "\n");
            }
        });

        JPanel botoes = new JPanel();
        botoes.add(addBtn);
        botoes.add(removeBtn);
        botoes.add(listarBtn);

        panel.add(botoes, BorderLayout.SOUTH);
        frame.add(panel);
        frame.setVisible(true);
    }
}
