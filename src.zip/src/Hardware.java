public class Hardware extends Item {
    private String serial;

    public Hardware(String id, String nome, String serial) {
        super(id, nome);
        this.serial = serial;
    }

    @Override
    public String getDetalhes() {
        return "Hardware SN: " + serial;
    }
}
