import java.util.ArrayList;
import java.util.List;

public class Estoque implements Gerenciador {
    private List<Item> itens = new ArrayList<>();

    @Override
    public void adicionar(Item item) throws ItemDuplicadoException {
        for (Item i : itens) {
            if (i.getId().equals(item.getId())) {
                throw new ItemDuplicadoException("Item com ID repetido!");
            }
        }
        itens.add(item);
        System.out.println("Adicionado: " + item);
    }

    @Override
    public void remover(String id) throws ItemNaoEncontradoException {
        Item achado = null;
        for (Item i : itens) {
            if (i.getId().equals(id)) achado = i;
        }
        if (achado == null) throw new ItemNaoEncontradoException("Item não encontrado!");
        itens.remove(achado);
        System.out.println("Removido: " + achado);
    }

    @Override
    public Item buscar(String id) throws ItemNaoEncontradoException {
        for (Item i : itens) {
            if (i.getId().equals(id)) return i;
        }
        throw new ItemNaoEncontradoException("Item não encontrado!");
    }

    @Override
    public List<Item> listar() {
        return itens;
    }
}
